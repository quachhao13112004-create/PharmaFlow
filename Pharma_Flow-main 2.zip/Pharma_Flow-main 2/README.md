# Pharma_Flow

Pharmacy management + online store. Plain Servlet/JSP on Tomcat 10, MySQL 8.

## Stack

- Java 17, Jakarta EE 10 — `jakarta.*` namespace
- JSP 3.x + JSTL 3.x, JDBC via MySQL Connector/J
- NetBeans Java Web project (Ant)

## Layout

```
├── lib/                           compile-only jars (NOT deployed)
│   └── jakarta.servlet-api.jar    provided by Tomcat at runtime
├── nbproject/                     NetBeans web project descriptor
├── src/java/
│   ├── controller/                HomeServlet, AuthenController, ProfileServlet,
│   │                              AdminServlet, StaffServlet, PosServlet
│   ├── dao/                       CategoryDAO, ProductDAO, UserDAO,
│   │                              CustomerProfileDAO, SupplierDAO (extends DBContext)
│   ├── db/                        DBContext — edit credentials here
│   ├── model/                     Category, Product, ProductType, User,
│   │                              CustomerProfile, Supplier
│   └── util/                      PasswordUtil (salted SHA-256)
└── web/                           webroot
    ├── WEB-INF/web.xml
    ├── WEB-INF/views/             JSPs (servlet-forwarded only)
    │   ├── home.jsp, error.jsp
    │   ├── auth/{login,register}.jsp
    │   ├── customer/profile.jsp
    │   ├── admin/dashboard.jsp    (stub)
    │   ├── staff/dashboard.jsp    (stub)
    │   └── pos/dashboard.jsp      (stub)
    ├── WEB-INF/jspf/              header, footer, product-card fragments
    ├── WEB-INF/lib/               runtime jars bundled into WAR (mysql + jstl)
    ├── css/, js/, images/
    └── index.jsp                  redirects to /home
```

## DB config

Single file: `src/java/db/DBContext.java` — edit `DB_URL` / `DB_USER` / `DB_PWD` directly.
Pattern follows the team's DBContext template (fresh `Connection` per call, driver loaded in ctor).

## Setup

1. JDK 17+, Tomcat 10+, MySQL 8.
2. Import schema: `mysql -u root -p < ../db_pharma.sql`
3. Place jars:
   - `lib/jakarta.servlet-api.jar` — copy from `$CATALINA_HOME/lib/servlet-api.jar` (compile-only, already present)
   - `web/WEB-INF/lib/mysql-connector-j.jar` — `com.mysql:mysql-connector-j:8.x`
   - `web/WEB-INF/lib/jakarta.servlet.jsp.jstl-api.jar` — `jakarta.servlet.jsp.jstl:jakarta.servlet.jsp.jstl-api:3.0.0`
   - `web/WEB-INF/lib/jakarta.servlet.jsp.jstl.jar` — `org.glassfish.web:jakarta.servlet.jsp.jstl:3.0.1`
4. Edit `db/DBContext.java` credentials if not root/blank.

Important: keep `jakarta.servlet-api.jar` out of `web/WEB-INF/lib/` — anything physically
in that folder is copied into the WAR, and shipping Tomcat's servlet API inside
the webapp breaks classloading.

## Build & run

Open in NetBeans → Clean & Build → produces `dist/Pharma_Flow.war` → deploy on Tomcat 10.

Open `http://localhost:8080/Pharma_Flow/`.

## Endpoints

| Path | Type | Purpose |
|------|------|---------|
| `/` | HTML | redirects to `/home` |
| `/home` | HTML | customer home page |
| `/products` | HTML | catalog grid, filters `?q=&category=&type=&page=` |
| `/products/{id}` | HTML | product detail (404 unless HOAT_DONG+online_sale_allowed) |
| `/authen?action=login` | HTML | sign-in form / POST login |
| `/authen?action=register` | HTML | register form / POST register |
| `/authen?action=logout` | — | invalidate session, redirect /home |
| `/profile` | HTML | customer self-profile (session-gated, KHACH_HANG only) |
| `/admin` | HTML | CHU_QUAN_QUAN_TRI dashboard (session-gated) |
| `/admin?action=categories` | HTML | admin: list all categories |
| `/admin?action=category-new` | HTML | admin: create form / POST `category-create` |
| `/admin?action=category-edit&id=N` | HTML | admin: edit form / POST `category-update` |
| `/admin?action=category-delete` (POST) | — | admin: soft-delete → status=NGUNG_HOAT_DONG |
| `/admin?action=suppliers` | HTML | admin: list all suppliers |
| `/admin?action=supplier-new` | HTML | admin: create form / POST `supplier-create` |
| `/admin?action=supplier-edit&id=N` | HTML | admin: edit form / POST `supplier-update` |
| `/admin?action=supplier-delete` (POST) | — | admin: soft-delete → status=NGUNG_HOAT_DONG |
| `/admin?action=products` | HTML | admin: list products (q/categoryId/type/status/page filters) |
| `/admin?action=product-new` | HTML | admin: create form / POST `product-create` |
| `/admin?action=product-edit&id=N` | HTML | admin: edit form / POST `product-update` |
| `/admin?action=product-delete` (POST) | — | admin: soft-delete → status=NGUNG_HOAT_DONG |
| `/staff` | HTML | STAFF landing (session-gated stub) |
| `/pos` | HTML | STAFF POS stub (session-gated, real POS in a later phase) |

## VNPAY Sandbox (local demo)

Checkout offers COD or `Thanh toán trực tuyến qua VNPAY` (Sandbox redirect only —
no IPN, no refund, no retry). Credentials come from env vars or JVM props,
never from the repo:

```bash
# env vars
VNPAY_TMN_CODE=<your sandbox terminal code>
VNPAY_HASH_SECRET=<your sandbox hash secret>
# or JVM props
-Dvnpay.tmnCode=<your sandbox terminal code> -Dvnpay.hashSecret=<your sandbox hash secret>
```

Flow: checkout → VNPAY → browser redirected to `https://sandbox.vnpayment.vn`
→ enter the Sandbox test card/OTP there → VNPAY returns to
`{scheme}://{host}/<context>/payment/vnpay/return` → `VnpayPaymentServlet`
verifies the HMAC-SHA512 signature + amount + state →
`VnpayPaymentDAO.processSuccess/processFailure` updates `online_payments` /
`online_orders` under row locks. Production must add the VNPAY IPN route —
the Return URL alone is only a demo convenience.

## Notes

- JSPs under `WEB-INF/views/` only reachable via servlet forward.
- Read-only catalog: no auth, no writes — no CSRF needed.
- Featured/HealthCare split is positional (first 8 by `product_id`, split 4+4) —
  schema has no "health care" flag.
- Purchasable rule: `product_type='KHONG_KE_DON'` AND `online_sale_allowed=1` AND in stock.
  KE_DON/HAN_CHE products render but with disabled Add-to-Cart.
- No JSON API for now — only JSP-rendered pages. Add `util/JsonUtil` when an API is needed.
- Auth: session-based, `currentUser` in `HttpSession`. Login accepts email or username.
  Public registration always forces `role=KHACH_HANG` and `status=HOAT_DONG` server-side.
  Passwords stored as `salt:hash` (SHA-256) via `util/PasswordUtil` — never plain text.
